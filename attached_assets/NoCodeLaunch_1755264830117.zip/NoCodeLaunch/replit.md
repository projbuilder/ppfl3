# Overview

This is a Privacy-Preserving Federated Learning (PPFL) surveillance system designed for distributed anomaly detection across edge devices. The system enables machine learning training on sensitive surveillance data without exposing raw data, using advanced privacy-preserving techniques including differential privacy and secure aggregation. The platform provides real-time monitoring, federated learning orchestration, and comprehensive privacy controls through a modern web interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with a modern React 18 stack using TypeScript and component-based design:

- **UI Framework**: shadcn/ui components built on Radix UI primitives for accessibility and design consistency
- **Styling**: Tailwind CSS with a custom cybersecurity-themed design system supporting dark mode
- **State Management**: TanStack Query for server state management with real-time caching and optimistic updates
- **Real-time Communication**: Custom WebSocket hook for live data streaming from federated learning rounds and anomaly detection
- **Build System**: Vite for fast development builds and optimized production bundles with TypeScript support

## Backend Architecture
The server follows a modular Express.js architecture with TypeScript:

- **API Layer**: RESTful endpoints for CRUD operations on surveillance data, federated learning rounds, edge devices, and privacy metrics
- **WebSocket Server**: Real-time bidirectional communication for live dashboard updates and client coordination
- **Service Layer**: Specialized services for anomaly detection, federated learning orchestration, and client simulation
- **Storage Abstraction**: Database layer using Drizzle ORM with PostgreSQL for type-safe operations

## Database Design
PostgreSQL database with Drizzle ORM providing comprehensive data modeling:

- **Edge Devices**: Device registry with capabilities, status monitoring, and federated learning participation tracking
- **Federated Learning Rounds**: Training round management with algorithm selection, aggregation methods, and convergence metrics
- **Anomaly Detections**: Security incident records with confidence scores, bounding boxes, and severity classifications
- **Privacy Metrics**: Differential privacy budget tracking with epsilon/delta monitoring across training rounds
- **User Management**: Authentication and authorization for system access

## Privacy-Preserving Features
The system implements enterprise-grade privacy protection mechanisms:

- **Differential Privacy**: Configurable epsilon budgets with noise injection during model training to protect individual data points
- **Secure Aggregation**: Cryptographic protocols for combining model updates without revealing individual contributions
- **Local Training**: Edge devices perform local model training on sensitive surveillance data without data sharing
- **Privacy Budget Monitoring**: Real-time tracking and alerting of privacy expenditure across federated learning rounds

## Federated Learning Architecture
Multi-algorithm federated learning system with robust aggregation:

- **Algorithm Support**: FedAvg, FedProx, and SCAFFOLD algorithms for different data distribution scenarios
- **Aggregation Methods**: Weighted averaging, Krum, trimmed mean, and cosine similarity filtering for outlier detection
- **Client Simulation**: Realistic simulation of 20+ edge devices with varying capabilities and network conditions
- **Round Orchestration**: Automated training round coordination with participant selection and convergence monitoring

## Real-time Processing Pipeline
Multi-stage surveillance and federated learning workflow:

- **File Upload Processing**: Support for images and videos with automated anomaly detection
- **Edge Device Coordination**: Dynamic client registration, heartbeat monitoring, and capability assessment
- **Live Dashboard Updates**: WebSocket-based real-time metrics, alerts, and status updates

# External Dependencies

## Database and Storage
- **Neon PostgreSQL**: Cloud-native PostgreSQL database with connection pooling
- **Drizzle ORM**: Type-safe database operations with schema migrations

## Frontend Libraries
- **React 18**: Core UI framework with modern hooks and concurrent features
- **Radix UI**: Accessible component primitives for complex UI interactions
- **TanStack Query**: Server state management with caching and real-time synchronization
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens

## Backend Services
- **Express.js**: Web framework for RESTful API and WebSocket server
- **WebSocket (ws)**: Real-time bidirectional communication for live updates
- **Multer**: File upload handling for surveillance media processing
- **Sharp**: Image processing for anomaly detection preprocessing

## Security and Privacy
- **TensorFlow.js**: Machine learning model execution for anomaly detection
- **UUID Generation**: Secure identifier generation for entities and sessions
- **CORS**: Cross-origin resource sharing configuration for API security

## Development Tools
- **TypeScript**: Type safety across frontend and backend codebases
- **Vite**: Fast development server with hot module replacement
- **ESBuild**: Production bundling for server-side code
- **tsx**: TypeScript execution for development workflows