import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, real, boolean, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const edgeDevices = pgTable("edge_devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: text("device_id").notNull().unique(),
  deviceType: text("device_type").notNull(),
  status: text("status").notNull().default("offline"),
  lastSeen: timestamp("last_seen").defaultNow(),
  capabilities: jsonb("capabilities"),
  location: text("location"),
  latency: integer("latency"),
  isParticipating: boolean("is_participating").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const federatedLearningRounds = pgTable("federated_learning_rounds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roundNumber: integer("round_number").notNull(),
  algorithm: text("algorithm").notNull().default("FedProx"),
  status: text("status").notNull().default("pending"),
  totalClients: integer("total_clients").notNull(),
  participatingClients: integer("participating_clients").default(0),
  convergenceMetric: real("convergence_metric"),
  accuracy: real("accuracy"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  aggregationMethod: text("aggregation_method").default("weighted_avg"),
});

export const anomalyDetections = pgTable("anomaly_detections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: varchar("device_id").references(() => edgeDevices.id),
  anomalyType: text("anomaly_type").notNull(),
  confidence: real("confidence").notNull(),
  severity: text("severity").notNull(),
  location: text("location"),
  boundingBox: jsonb("bounding_box"),
  fileName: text("file_name"),
  fileType: text("file_type"),
  filePath: text("file_path"),
  detectedAt: timestamp("detected_at").defaultNow(),
  isResolved: boolean("is_resolved").default(false),
});

export const privacyMetrics = pgTable("privacy_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  roundId: varchar("round_id").references(() => federatedLearningRounds.id),
  epsilon: real("epsilon").notNull(),
  delta: real("delta").notNull(),
  budgetUsed: real("budget_used").notNull(),
  budgetRemaining: real("budget_remaining").notNull(),
  mechanism: text("mechanism").default("gaussian"),
  recordedAt: timestamp("recorded_at").defaultNow(),
});

export const modelRegistry = pgTable("model_registry", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelName: text("model_name").notNull(),
  version: text("version").notNull(),
  roundId: varchar("round_id").references(() => federatedLearningRounds.id),
  accuracy: real("accuracy"),
  modelSize: integer("model_size"),
  isDeployed: boolean("is_deployed").default(false),
  deployedAt: timestamp("deployed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  metadata: jsonb("metadata"),
});

// Relations
export const edgeDeviceRelations = relations(edgeDevices, ({ many }) => ({
  anomalies: many(anomalyDetections),
}));

export const federatedLearningRoundRelations = relations(federatedLearningRounds, ({ many }) => ({
  privacyMetrics: many(privacyMetrics),
  models: many(modelRegistry),
}));

export const anomalyDetectionRelations = relations(anomalyDetections, ({ one }) => ({
  device: one(edgeDevices, {
    fields: [anomalyDetections.deviceId],
    references: [edgeDevices.id],
  }),
}));

export const privacyMetricRelations = relations(privacyMetrics, ({ one }) => ({
  round: one(federatedLearningRounds, {
    fields: [privacyMetrics.roundId],
    references: [federatedLearningRounds.id],
  }),
}));

export const modelRegistryRelations = relations(modelRegistry, ({ one }) => ({
  round: one(federatedLearningRounds, {
    fields: [modelRegistry.roundId],
    references: [federatedLearningRounds.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertEdgeDeviceSchema = createInsertSchema(edgeDevices).omit({
  id: true,
  createdAt: true,
});

export const insertFLRoundSchema = createInsertSchema(federatedLearningRounds).omit({
  id: true,
  startedAt: true,
});

export const insertAnomalySchema = createInsertSchema(anomalyDetections).omit({
  id: true,
  detectedAt: true,
});

export const insertPrivacyMetricSchema = createInsertSchema(privacyMetrics).omit({
  id: true,
  recordedAt: true,
});

export const insertModelSchema = createInsertSchema(modelRegistry).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type EdgeDevice = typeof edgeDevices.$inferSelect;
export type InsertEdgeDevice = z.infer<typeof insertEdgeDeviceSchema>;

export type FederatedLearningRound = typeof federatedLearningRounds.$inferSelect;
export type InsertFLRound = z.infer<typeof insertFLRoundSchema>;

export type AnomalyDetection = typeof anomalyDetections.$inferSelect;
export type InsertAnomaly = z.infer<typeof insertAnomalySchema>;

export type PrivacyMetric = typeof privacyMetrics.$inferSelect;
export type InsertPrivacyMetric = z.infer<typeof insertPrivacyMetricSchema>;

export type ModelRegistry = typeof modelRegistry.$inferSelect;
export type InsertModel = z.infer<typeof insertModelSchema>;
